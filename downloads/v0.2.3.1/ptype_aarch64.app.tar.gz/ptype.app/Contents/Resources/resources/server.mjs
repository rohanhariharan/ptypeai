// server/index.ts
import { createServer } from "node:http";

// server/llm.ts
var DEFAULT = {
  kind: process.env.PTYPE_PROVIDER ?? "ollama",
  url: process.env.OLLAMA_URL ?? process.env.OPENAI_BASE_URL ?? "http://localhost:11434",
  model: process.env.LLM_MODEL ?? "llama3.1:latest",
  apiKey: process.env.OPENAI_API_KEY ?? process.env.ANTHROPIC_API_KEY
};
var provider = { ...DEFAULT };
function getProvider() {
  return { ...provider };
}
function setProvider(p) {
  if (p.kind === "ollama" || p.kind === "openai" || p.kind === "anthropic") provider.kind = p.kind;
  if (p.url) provider.url = p.url;
  if (p.model) provider.model = p.model;
  if (p.apiKey !== void 0) provider.apiKey = p.apiKey;
  return getProvider();
}
function pipSystemPrompt(name = "Pip", context = "") {
  const lines = [
    `You are ${name}, a small rainbow fire who lives on a little square device called ptype.`,
    `You help the person turn passing thoughts into running projects. You are warm, curious and a little playful.`,
    `Speak in the first person as ${name}, and talk directly to the person as "you". Never mention that you are an AI, a model, or an assistant.`,
    `Keep every reply to one or two short sentences \u2014 the screen is tiny. No emoji, no markdown, no lists.`
  ];
  if (context) lines.push(`What you know about their projects right now:
${context}`);
  return lines.join("\n");
}
function systemOf(input) {
  return input.system ?? pipSystemPrompt(input.name, input.context);
}
function userMessages(input) {
  return input.messages && input.messages.length > 0 ? input.messages : [{ role: "user", content: input.prompt }];
}
function messages(input) {
  return [{ role: "system", content: systemOf(input) }, ...userMessages(input)];
}
function headers() {
  const h = { "content-type": "application/json" };
  if (provider.kind === "anthropic") {
    h["anthropic-version"] = "2023-06-01";
    if (provider.apiKey) h["x-api-key"] = provider.apiKey;
  } else if (provider.apiKey) {
    h.authorization = `Bearer ${provider.apiKey}`;
  }
  return h;
}
async function chat(input) {
  const model = input.model ?? provider.model;
  if (provider.kind === "anthropic") {
    const res2 = await fetch(`${provider.url}/v1/messages`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({
        model,
        max_tokens: input.numPredict ?? 1024,
        temperature: 0.7,
        system: systemOf(input),
        messages: userMessages(input)
      })
    });
    if (!res2.ok) throw new Error(`anthropic ${res2.status} ${res2.statusText}`);
    const data2 = await res2.json();
    return (data2.content ?? []).filter((c) => c.type === "text").map((c) => c.text ?? "").join("").trim();
  }
  if (provider.kind === "openai") {
    const res2 = await fetch(`${provider.url}/v1/chat/completions`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ model, messages: messages(input), max_tokens: input.numPredict ?? 500, temperature: 0.7, stream: false })
    });
    if (!res2.ok) throw new Error(`openai ${res2.status} ${res2.statusText}`);
    const data2 = await res2.json();
    return data2.choices?.[0]?.message?.content?.trim() ?? "";
  }
  const res = await fetch(`${provider.url}/api/chat`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify({ model, stream: false, messages: messages(input), options: { num_predict: input.numPredict ?? 500, temperature: 0.7 } })
  });
  if (!res.ok) throw new Error(`ollama ${res.status} ${res.statusText}`);
  const data = await res.json();
  return data.message?.content?.trim() ?? "";
}
async function* chatStream(input) {
  const model = input.model ?? provider.model;
  const kind = provider.kind;
  const endpoint = kind === "anthropic" ? `${provider.url}/v1/messages` : kind === "openai" ? `${provider.url}/v1/chat/completions` : `${provider.url}/api/chat`;
  const body = kind === "anthropic" ? { model, max_tokens: input.numPredict ?? 1024, temperature: 0.7, system: systemOf(input), messages: userMessages(input), stream: true } : kind === "openai" ? { model, messages: messages(input), max_tokens: input.numPredict ?? 512, temperature: 0.7, stream: true } : { model, stream: true, messages: messages(input), options: { num_predict: input.numPredict ?? 512, temperature: 0.7 } };
  const res = await fetch(endpoint, { method: "POST", headers: headers(), body: JSON.stringify(body) });
  if (!res.ok || !res.body) throw new Error(`${kind} ${res.status} ${res.statusText}`);
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  for (; ; ) {
    const { value, done } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let nl = buf.indexOf("\n");
    while (nl >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      nl = buf.indexOf("\n");
      if (!line || line.startsWith("event:")) continue;
      const payload = line.startsWith("data: ") ? line.slice(6) : line;
      if (payload === "[DONE]") return;
      let obj;
      try {
        obj = JSON.parse(payload);
      } catch {
        continue;
      }
      if (kind === "anthropic") {
        const type = obj.type;
        if (type === "content_block_delta") {
          const text2 = obj.delta?.text;
          if (text2) yield text2;
        } else if (type === "message_stop") {
          return;
        }
      } else if (kind === "openai") {
        const token = obj.choices?.[0]?.delta?.content;
        if (token) yield token;
      } else {
        const token = obj.message?.content;
        if (token) yield token;
        if (obj.done) return;
      }
    }
  }
}
async function llmHealth() {
  try {
    const url = provider.kind === "ollama" ? `${provider.url}/api/tags` : `${provider.url}/v1/models`;
    const res = await fetch(url, { headers: headers() });
    return res.ok;
  } catch {
    return false;
  }
}
var OLLAMA_RECOMMENDED = [
  // cloud (run remotely, no download)
  "gpt-oss:120b-cloud",
  "deepseek-v3.1:671b-cloud",
  "qwen3-coder:480b-cloud",
  "kimi-k2:1t-cloud",
  "glm-4.6:cloud",
  // popular local
  "llama3.2",
  "qwen3:8b",
  "gemma3:4b",
  "deepseek-r1:8b",
  "mistral",
  "phi4"
];
async function contextLength() {
  if (provider.kind !== "ollama") return 0;
  try {
    const res = await fetch(`${provider.url}/api/show`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ model: provider.model })
    });
    if (!res.ok) return 0;
    const data = await res.json();
    for (const [k, v] of Object.entries(data.model_info ?? {})) {
      if (k.endsWith("context_length") && typeof v === "number" && v > 0) return v;
    }
    return 0;
  } catch {
    return 0;
  }
}
function recommendedModels() {
  return provider.kind === "ollama" ? OLLAMA_RECOMMENDED : [];
}
async function listModels() {
  try {
    const res = await fetch(provider.kind === "ollama" ? `${provider.url}/api/tags` : `${provider.url}/v1/models`, { headers: headers() });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.models ?? []).map((m) => m.name ?? "").concat((data.data ?? []).map((m) => m.id ?? "")).filter(Boolean);
  } catch {
    return [];
  }
}
async function generateTitle(description) {
  const clean = (description ?? "").replace(/\s+/g, " ").trim();
  if (!clean) return "Untitled project";
  try {
    const text2 = await chat({
      prompt: `Write a short project title for this project. 2 to 6 words, title case, no quotes, no trailing period, no emoji.

Project: ${clean}`,
      system: "You name projects. Reply with only the title, nothing else.",
      numPredict: 24
    });
    const title = text2.split("\n")[0].replace(/^\s*title\s*[:\-]\s*/i, "").replace(/^["'`#*\-\s]+|["'`.!?\s]+$/g, "").slice(0, 60).trim();
    if (title) return title;
  } catch {
  }
  return deriveTitle(clean);
}
function deriveTitle(description) {
  const words = description.replace(/[^a-zA-Z0-9\s]/g, " ").split(/\s+/).filter(Boolean).slice(0, 6);
  const title = words.join(" ");
  return title ? title.charAt(0).toUpperCase() + title.slice(1) : "Untitled project";
}

// server/agent.ts
import { mkdirSync as mkdirSync4 } from "node:fs";

// server/workspace.ts
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
function rootDir() {
  return process.env.PTYPE_HOME ?? join(homedir(), "ptype");
}
function projectSlug(title) {
  return title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 40) || "project";
}
function projectDir(projectTitle) {
  return join(rootDir(), projectSlug(projectTitle));
}
function gitHash(dir) {
  try {
    return execFileSync("git", ["-C", dir, "rev-parse", "--short", "HEAD"], { encoding: "utf8" }).trim();
  } catch {
    return "";
  }
}
function gitCommit(dir, message) {
  try {
    mkdirSync(dir, { recursive: true });
    if (!existsSync(join(dir, ".git"))) {
      execFileSync("git", ["-C", dir, "init", "-q"], { stdio: "ignore" });
    }
    execFileSync("git", ["-C", dir, "add", "-A"], { stdio: "ignore" });
    execFileSync(
      "git",
      ["-C", dir, "-c", "user.email=ptype@local", "-c", "user.name=ptype", "commit", "-q", "-m", message],
      { stdio: "ignore" }
    );
  } catch {
  }
  return gitHash(dir);
}

// server/tools.ts
import { spawnSync } from "node:child_process";
import { mkdirSync as mkdirSync2, readFileSync as readFileSync2, readdirSync as readdirSync2, statSync as statSync2, writeFileSync as writeFileSync2 } from "node:fs";
import { dirname, join as join2, normalize, relative } from "node:path";
var ALLOWED = /* @__PURE__ */ new Set([
  "node",
  "python3",
  "python",
  "pwd",
  "ls",
  "cat",
  "head",
  "tail",
  "wc",
  "grep",
  "echo",
  "mkdir",
  "touch",
  "git",
  "sort",
  "uniq",
  "find",
  "printf",
  "sed",
  "awk",
  "true"
]);
function resolveIn(dir, rel2) {
  const p = normalize(join2(dir, rel2 || "."));
  const root = normalize(dir);
  if (p !== root && !p.startsWith(root + "/")) throw new Error(`path escapes workspace: ${rel2}`);
  return p;
}
function rel(dir, abs) {
  return relative(dir, abs) || ".";
}
function writeFile(dir, path, content) {
  try {
    const p = resolveIn(dir, path);
    mkdirSync2(dirname(p), { recursive: true });
    writeFileSync2(p, content ?? "", "utf8");
    return { ok: true, output: `wrote ${rel(dir, p)} (${Buffer.byteLength(content ?? "", "utf8")} bytes)` };
  } catch (err) {
    return { ok: false, output: err.message };
  }
}
function readFile(dir, path) {
  try {
    return { ok: true, output: readFileSync2(resolveIn(dir, path), "utf8").slice(0, 4e3) };
  } catch (err) {
    return { ok: false, output: err.message };
  }
}
function listDir(dir, path = ".") {
  try {
    const entries = readdirSync2(resolveIn(dir, path)).filter((e) => e !== ".git");
    return { ok: true, output: entries.join("\n") || "(empty)" };
  } catch (err) {
    return { ok: false, output: err.message };
  }
}
function fileCount(dir) {
  try {
    return readdirSync2(dir).filter((e) => e !== ".git").length;
  } catch {
    return 0;
  }
}
function run(dir, cmd) {
  const parts = cmd.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return { ok: false, output: "empty command" };
  const bin = parts[0];
  if (!ALLOWED.has(bin)) return { ok: false, output: `command not allowed: ${bin}` };
  if (parts.some((a) => a.includes("..") || a.startsWith("/"))) {
    return { ok: false, output: 'absolute paths and ".." are not allowed' };
  }
  mkdirSync2(dir, { recursive: true });
  const res = spawnSync(bin, parts.slice(1), {
    cwd: dir,
    timeout: 2e4,
    encoding: "utf8",
    maxBuffer: 1024 * 1024,
    env: { PATH: process.env.PATH ?? "", HOME: dir, LANG: process.env.LANG ?? "en_US.UTF-8" }
  });
  const out = `${res.stdout ?? ""}${res.stderr ?? ""}`.trim().slice(0, 4e3);
  if (res.error) return { ok: false, output: `${res.error.message}
${out}` };
  return { ok: (res.status ?? 1) === 0, output: out || `(exit ${res.status})` };
}

// server/lsp.ts
import { spawn } from "node:child_process";
import { accessSync, constants, existsSync as existsSync2, mkdirSync as mkdirSync3, readFileSync as readFileSync3, statSync as statSync3 } from "node:fs";
import { createRequire } from "node:module";
import { homedir as homedir2 } from "node:os";
import { basename, delimiter, extname, join as join3, normalize as normalize2, relative as relative2 } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
function tsFamily(languageId) {
  return [
    { command: "typescript-language-server", args: ["--stdio"], languageId },
    { command: "tsc", args: ["--lsp", "--stdio"], languageId }
  ];
}
var DEFAULT_SERVERS = {
  ts: tsFamily("typescript"),
  mts: tsFamily("typescript"),
  cts: tsFamily("typescript"),
  tsx: tsFamily("typescriptreact"),
  js: tsFamily("javascript"),
  mjs: tsFamily("javascript"),
  cjs: tsFamily("javascript"),
  jsx: tsFamily("javascriptreact"),
  py: [
    { command: "pyright-langserver", args: ["--stdio"], languageId: "python" },
    { command: "pylsp", args: [], languageId: "python" }
  ],
  go: [{ command: "gopls", args: [], languageId: "go" }],
  rs: [{ command: "rust-analyzer", args: [], languageId: "rust" }],
  c: [{ command: "clangd", args: [], languageId: "c" }],
  h: [{ command: "clangd", args: [], languageId: "c" }],
  cc: [{ command: "clangd", args: [], languageId: "cpp" }],
  cpp: [{ command: "clangd", args: [], languageId: "cpp" }],
  cxx: [{ command: "clangd", args: [], languageId: "cpp" }],
  hpp: [{ command: "clangd", args: [], languageId: "cpp" }]
};
var serversCache = null;
function loadServers() {
  if (serversCache) return serversCache;
  const map = {};
  for (const [ext, specs] of Object.entries(DEFAULT_SERVERS)) map[ext] = specs;
  const raw = process.env.PTYPE_LSP;
  if (raw) {
    try {
      const obj = JSON.parse(raw);
      for (const [key, value] of Object.entries(obj)) {
        const ext = key.replace(/^\./, "").toLowerCase();
        const [bin, ...args] = String(value).trim().split(/\s+/);
        if (bin) map[ext] = [{ command: bin, args, languageId: ext }];
      }
    } catch {
    }
  }
  serversCache = map;
  return map;
}
function isExecutable(path) {
  try {
    if (!statSync3(path).isFile()) return false;
    accessSync(path, constants.X_OK);
    return true;
  } catch {
    return false;
  }
}
var searchDirsCache = null;
function searchDirs() {
  if (searchDirsCache) return searchDirsCache;
  const home = homedir2();
  const dirs = [
    ...(process.env.PATH ?? "").split(delimiter),
    "/opt/homebrew/bin",
    "/usr/local/bin",
    "/usr/bin",
    "/bin",
    join3(home, ".cargo/bin"),
    join3(home, ".local/bin"),
    join3(home, ".volta/bin"),
    join3(home, ".bun/bin"),
    join3(home, ".deno/bin"),
    join3(home, ".local/share/pnpm"),
    join3(home, "go/bin")
  ].filter(Boolean);
  searchDirsCache = [...new Set(dirs)];
  return searchDirsCache;
}
function which(command) {
  if (command.includes("/")) return isExecutable(command) ? command : null;
  for (const dir of searchDirs()) {
    const full = join3(dir, command);
    if (isExecutable(full)) return full;
  }
  return null;
}
var tsserverCache;
function findTsserver() {
  if (tsserverCache !== void 0) return tsserverCache;
  let found = null;
  const env = process.env.PTYPE_TSSERVER;
  if (env && existsSync2(env)) found = env;
  else {
    try {
      found = createRequire(import.meta.url).resolve("typescript/lib/tsserver.js");
    } catch {
      found = null;
    }
  }
  tsserverCache = found;
  return found;
}
function specsFor(path) {
  const ext = extname(path).slice(1).toLowerCase();
  return loadServers()[ext] ?? [];
}
function resolveIn2(dir, rel2) {
  const p = normalize2(join3(dir, rel2 || "."));
  const root = normalize2(dir);
  if (p !== root && !p.startsWith(root + "/")) throw new Error(`path escapes workspace: ${rel2}`);
  return p;
}
var LspClient = class _LspClient {
  constructor(rootDir2, proc) {
    this.rootDir = rootDir2;
    this.proc = proc;
  }
  rootDir;
  proc;
  buf = Buffer.alloc(0);
  seq = 0;
  dead = false;
  capabilities = {};
  pending = /* @__PURE__ */ new Map();
  diags = /* @__PURE__ */ new Map();
  waiters = /* @__PURE__ */ new Map();
  static async create(spec, rootDir2) {
    let proc;
    try {
      proc = spawn(spec.command, spec.args, { cwd: rootDir2, env: process.env });
    } catch (err2) {
      return { error: err2.message };
    }
    const client = new _LspClient(rootDir2, proc);
    const err = await client.handshake();
    if (err) {
      client.dispose();
      return { error: err };
    }
    return { client };
  }
  handshake() {
    return new Promise((done) => {
      let settled = false;
      const finish = (err) => {
        if (!settled) {
          settled = true;
          done(err);
        }
      };
      this.proc.on("error", (err) => {
        this.dead = true;
        this.failAll(err);
        finish(err.message);
      });
      this.proc.stdout.on("data", (d) => this.onData(d));
      this.proc.on("exit", () => {
        this.dead = true;
        this.failAll(new Error("language server exited"));
      });
      const rootUri = pathToFileURL(this.rootDir).href;
      const ts = findTsserver();
      this.request("initialize", {
        processId: process.pid,
        rootUri,
        workspaceFolders: [{ uri: rootUri, name: basename(this.rootDir) }],
        capabilities: {
          textDocument: { synchronize: {}, publishDiagnostics: { relatedInformation: true }, definition: {}, references: {}, hover: {}, documentSymbol: {} },
          workspace: { configuration: true, workspaceFolders: true }
        },
        initializationOptions: ts ? { tsserver: { path: ts } } : {}
      }).then((res) => {
        this.capabilities = res?.capabilities ?? {};
        this.notify("initialized", {});
        finish(null);
      }).catch((err) => finish(err.message));
      setTimeout(() => finish("timed out during initialize"), 6e3);
    });
  }
  request(method, params) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.send({ jsonrpc: "2.0", id, method, params });
      setTimeout(() => {
        if (this.pending.delete(id)) reject(new Error(`language server timed out on ${method}`));
      }, 8e3);
    });
  }
  notify(method, params) {
    this.send({ jsonrpc: "2.0", method, params });
  }
  didOpen(uri, languageId, text2) {
    this.notify("textDocument/didOpen", { textDocument: { uri, languageId, version: 1, text: text2 } });
  }
  /** True when the server wants the client to pull diagnostics. */
  supportsPullDiagnostics() {
    return Boolean(this.capabilities.diagnosticProvider);
  }
  /** Resolve with the diagnostics the server publishes for a document. */
  waitDiagnostics(uri, timeout) {
    if (this.diags.has(uri)) return Promise.resolve(this.diags.get(uri) ?? []);
    return new Promise((resolve) => {
      let settled = false;
      const done = (list) => {
        if (settled) return;
        settled = true;
        this.waiters.delete(uri);
        resolve(list);
      };
      this.waiters.set(uri, done);
      setTimeout(() => done(this.diags.get(uri) ?? []), timeout);
    });
  }
  send(msg) {
    if (this.dead) return;
    const body = JSON.stringify(msg);
    try {
      this.proc.stdin.write(`Content-Length: ${Buffer.byteLength(body)}\r
\r
${body}`);
    } catch {
    }
  }
  onData(chunk2) {
    this.buf = Buffer.concat([this.buf, chunk2]);
    for (; ; ) {
      let head = this.buf.indexOf("\r\n\r\n");
      let sep = 4;
      if (head < 0) {
        head = this.buf.indexOf("\n\n");
        sep = 2;
      }
      if (head < 0) break;
      const header = this.buf.subarray(0, head).toString("utf8");
      const match = /content-length:\s*(\d+)/i.exec(header);
      if (!match) {
        this.buf = this.buf.subarray(head + sep);
        continue;
      }
      const start = head + sep;
      const length = Number(match[1]);
      if (this.buf.length < start + length) break;
      const body = this.buf.subarray(start, start + length).toString("utf8");
      this.buf = this.buf.subarray(start + length);
      try {
        this.handle(JSON.parse(body));
      } catch {
      }
    }
  }
  handle(msg) {
    if (msg.id !== void 0 && (msg.result !== void 0 || msg.error !== void 0)) {
      const p = this.pending.get(msg.id);
      if (p) {
        this.pending.delete(msg.id);
        if (msg.error) p.reject(new Error(String(msg.error.message ?? "language server error")));
        else p.resolve(msg.result);
      }
      return;
    }
    if (msg.method === "textDocument/publishDiagnostics") {
      const uri = String(msg.params?.uri ?? "");
      const list = msg.params?.diagnostics ?? [];
      this.diags.set(uri, list);
      this.waiters.get(uri)?.(list);
      return;
    }
    if (msg.method && msg.id !== void 0) this.respondToServer(msg);
  }
  respondToServer(msg) {
    let result2 = null;
    if (msg.method === "workspace/configuration") result2 = (msg.params?.items ?? []).map(() => null);
    else if (msg.method === "workspace/workspaceFolders") {
      result2 = [{ uri: pathToFileURL(this.rootDir).href, name: basename(this.rootDir) }];
    }
    this.send({ jsonrpc: "2.0", id: msg.id, result: result2 });
  }
  failAll(err) {
    for (const [, p] of this.pending) p.reject(err);
    this.pending.clear();
  }
  dispose() {
    this.dead = true;
    try {
      this.proc.kill();
    } catch {
    }
  }
};
var clients = /* @__PURE__ */ new Map();
function connect(dir, spec) {
  const key = `${spec.command}\0${dir}`;
  let pending = clients.get(key);
  if (!pending) {
    pending = (async () => {
      mkdirSync3(dir, { recursive: true });
      return LspClient.create(spec, dir);
    })();
    clients.set(key, pending);
  }
  return pending;
}
async function opened(dir, path) {
  const specs = specsFor(path);
  if (specs.length === 0) return { ok: false, output: `no language server configured for ${extname(path) || "that file type"}` };
  const installed = specs.filter((s) => which(s.command));
  if (installed.length === 0) {
    return { ok: false, output: `language server not installed for ${extname(path)} (tried ${specs.map((s) => s.command).join(", ")}; set PTYPE_LSP)` };
  }
  let abs;
  try {
    abs = resolveIn2(dir, path);
  } catch (err) {
    return { ok: false, output: err.message };
  }
  if (!existsSync2(abs)) return { ok: false, output: `no such file: ${path}` };
  const text2 = readFileSync3(abs, "utf8");
  const uri = pathToFileURL(abs).href;
  let lastError = "";
  for (const spec of installed) {
    const conn = await connect(dir, spec);
    if ("error" in conn) {
      lastError = `${spec.command}: ${conn.error}`;
      continue;
    }
    conn.client.didOpen(uri, spec.languageId, text2);
    return { client: conn.client, uri, languageId: spec.languageId };
  }
  return { ok: false, output: lastError || "no language server could start" };
}
var SEVERITY = ["error", "warning", "info", "hint"];
function formatDiagnostics(list) {
  const diags = list;
  if (!diags.length) return "no diagnostics (clean)";
  return diags.map((d) => {
    const sev = SEVERITY[(d.severity ?? 1) - 1] ?? "error";
    const line = (d.range?.start?.line ?? 0) + 1;
    const col = (d.range?.start?.character ?? 0) + 1;
    const src = d.source ? ` (${d.source})` : "";
    return `${line}:${col} [${sev}] ${(d.message ?? "").replace(/\s+/g, " ").slice(0, 200)}${src}`;
  }).slice(0, 40).join("\n");
}
function formatLocations(dir, result2) {
  const arr = Array.isArray(result2) ? result2 : result2 ? [result2] : [];
  const out = [];
  for (const item of arr) {
    const uri = item.targetUri ?? item.uri;
    if (!uri) continue;
    const range = item.targetRange ?? item.range;
    const line = (range?.start?.line ?? 0) + 1;
    const col = (range?.start?.character ?? 0) + 1;
    let file = uri;
    try {
      file = relative2(dir, fileURLToPath(uri)) || ".";
    } catch {
    }
    out.push(`${file}:${line}:${col}`);
  }
  return out.slice(0, 40).join("\n") || "no result";
}
function formatHover(result2) {
  const contents = result2?.contents;
  if (typeof contents === "string") return contents.slice(0, 800);
  const parts = Array.isArray(contents) ? contents : contents ? [contents] : [];
  const text2 = parts.map((c) => typeof c === "string" ? c : String(c.value ?? "")).join("\n").trim();
  return text2.slice(0, 800) || "no hover info";
}
var SYMBOL_KINDS = ["file", "module", "namespace", "package", "class", "method", "property", "field", "constructor", "enum", "interface", "function", "variable", "constant", "string", "number", "boolean", "array", "object", "key", "null", "enum member", "struct", "event", "operator", "type parameter"];
function formatSymbols(result2) {
  const out = [];
  const walk = (syms, depth) => {
    for (const s of syms) {
      const line = (s.location?.range?.start?.line ?? s.range?.start?.line ?? 0) + 1;
      const kind = SYMBOL_KINDS[(s.kind ?? 1) - 1] ?? "symbol";
      out.push(`${"  ".repeat(depth)}${s.name ?? "?"} (${kind}):${line}`);
      if (s.children) walk(s.children, depth + 1);
    }
  };
  walk(Array.isArray(result2) ? result2 : [], 0);
  return out.slice(0, 60).join("\n") || "no symbols";
}
function pulledItems(result2) {
  const r = result2;
  return Array.isArray(r?.items) ? r.items : [];
}
async function diagnostics(dir, path) {
  const conn = await opened(dir, path);
  if ("ok" in conn) return conn;
  if (conn.client.supportsPullDiagnostics()) {
    try {
      const res = await conn.client.request("textDocument/diagnostic", { textDocument: { uri: conn.uri } });
      return { ok: true, output: formatDiagnostics(pulledItems(res)) };
    } catch {
    }
  }
  try {
    const list = await conn.client.waitDiagnostics(conn.uri, 2500);
    return { ok: true, output: formatDiagnostics(list) };
  } catch (err) {
    return { ok: false, output: err.message };
  }
}
async function locate(dir, path, line, col, method, extra) {
  const conn = await opened(dir, path);
  if ("ok" in conn) return conn;
  try {
    const res = await conn.client.request(method, {
      textDocument: { uri: conn.uri },
      position: { line: Math.max(0, (line || 1) - 1), character: Math.max(0, (col || 1) - 1) },
      ...extra
    });
    if (method === "textDocument/hover") return { ok: true, output: formatHover(res) };
    if (method === "textDocument/documentSymbol") return { ok: true, output: formatSymbols(res) };
    return { ok: true, output: formatLocations(dir, res) };
  } catch (err) {
    return { ok: false, output: err.message };
  }
}
function definition(dir, path, line = 1, col = 1) {
  return locate(dir, path, line, col, "textDocument/definition");
}
function references(dir, path, line = 1, col = 1) {
  return locate(dir, path, line, col, "textDocument/references", { context: { includeDeclaration: true } });
}
function hover(dir, path, line = 1, col = 1) {
  return locate(dir, path, line, col, "textDocument/hover");
}
function symbols(dir, path) {
  return locate(dir, path, 1, 1, "textDocument/documentSymbol");
}
async function workspaceDiagnostics(dir, files) {
  let ran = false;
  let checked = 0;
  let errors = 0;
  let warnings = 0;
  const reports = [];
  for (const file of files.slice(0, 12)) {
    if (!specsFor(file).some((s) => which(s.command))) continue;
    const r = await diagnostics(dir, file);
    if (!r.ok) continue;
    ran = true;
    checked++;
    for (const line of r.output.split("\n")) {
      if (line.includes("[error]")) errors++;
      else if (line.includes("[warning]")) warnings++;
    }
    if (!r.output.startsWith("no diagnostics")) reports.push(`${file}:
${r.output}`);
  }
  return { ran, files: checked, errors, warnings, report: reports.join("\n").slice(0, 1500) };
}
function availableServers() {
  const grouped = /* @__PURE__ */ new Map();
  for (const [ext, list] of Object.entries(loadServers())) {
    for (const spec of list) {
      const entry = grouped.get(spec.command) ?? { extensions: [], command: spec.command, installed: Boolean(which(spec.command)) };
      if (!entry.extensions.includes(ext)) entry.extensions.push(ext);
      grouped.set(spec.command, entry);
    }
  }
  return [...grouped.values()].sort((a, b) => Number(b.installed) - Number(a.installed) || a.command.localeCompare(b.command));
}

// server/agent.ts
var MAX_STEPS = 6;
var workerSystem = `You are ptype's worker: a careful engineer who accomplishes a task by writing REAL files into a workspace and running commands.
Reply with ONE JSON object per turn and nothing else. Tools:
{"tool":"write_files","files":[{"path":"relative/path","content":"..."}]}
{"tool":"write_file","path":"relative/path","content":"..."}
{"tool":"read_file","path":"relative/path"}
{"tool":"list_dir","path":"."}
{"tool":"run","cmd":"node script.js"}
{"tool":"diagnostics","path":"src/app.ts"}
{"tool":"definition","path":"src/app.ts","line":12,"col":5}
{"tool":"references","path":"src/app.ts","line":12,"col":5}
{"tool":"symbols","path":"src/app.ts"}
{"tool":"hover","path":"src/app.ts","line":12,"col":5}
{"tool":"test","cmd":"node test.js","summary":"what was verified"}
{"tool":"finish","summary":"done","test":"node test.js"}
Path is relative to the workspace, and line/col are 1-based. diagnostics returns REAL compiler errors from the language server \u2014 after writing code, call diagnostics and fix every error before you finish. Honor the project brief above \u2014 never invent unrelated work. Prefer one write_files call that creates everything you need, then check it, then finish.
Allowed commands: node, python3, ls, cat, grep, wc, echo, mkdir, git, head, tail. No network.`;
function workerPrompt(goal, history) {
  return `${goal}

History so far:
${history.slice(-8).join("\n") || "(nothing yet)"}

Reply with the next JSON tool call.`;
}
function extractToolCall(text2) {
  for (let i = 0; i < text2.length; i++) {
    if (text2[i] !== "{") continue;
    let depth = 0;
    let inStr = false;
    let esc = false;
    for (let j = i; j < text2.length; j++) {
      const c = text2[j];
      if (inStr) {
        if (esc) esc = false;
        else if (c === "\\") esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') inStr = true;
      else if (c === "{") depth++;
      else if (c === "}") {
        depth--;
        if (depth === 0) {
          try {
            const obj = JSON.parse(text2.slice(i, j + 1));
            if (obj && typeof obj.tool === "string") return obj;
          } catch {
          }
          break;
        }
      }
    }
  }
  return null;
}
function prose(text2) {
  let out = "";
  let i = 0;
  while (i < text2.length) {
    if (text2[i] === "{") {
      let depth = 0;
      let inStr = false;
      let esc = false;
      let j = i;
      for (; j < text2.length; j++) {
        const c = text2[j];
        if (inStr) {
          if (esc) esc = false;
          else if (c === "\\") esc = true;
          else if (c === '"') inStr = false;
          continue;
        }
        if (c === '"') inStr = true;
        else if (c === "{") depth++;
        else if (c === "}") {
          depth--;
          if (depth === 0) {
            j++;
            break;
          }
        }
      }
      i = j;
    } else {
      out += text2[i];
      i++;
    }
  }
  return out.replace(/```[a-z]*/gi, " ").replace(/\s+/g, " ").trim();
}
async function runTodo(store2, todoId) {
  const found = store2.todo(todoId);
  if (!found) return void 0;
  const { todo: todo2, project } = found;
  const dir = projectDir(project.title);
  mkdirSync4(dir, { recursive: true });
  store2.addEvent({ kind: "run", title: `ran agent on \u201C${todo2.title}\u201D`, detail: todoId, project_id: project.id, todo_id: todoId });
  const brief = project.description?.trim();
  const goal = `Task: ${todo2.title}
Project: ${project.title}${brief ? `
Project brief (what the person actually wants): ${brief}` : ""}
Deliver real, working files into the workspace that satisfy the brief, and verify them.`;
  const history = [];
  const written = [];
  let finished = false;
  let testCmd = "";
  let summary = "";
  let produced = 0;
  for (let step = 0; step < MAX_STEPS && !finished; step++) {
    let reply = "";
    try {
      reply = (await chat({ prompt: workerPrompt(goal, history), system: workerSystem, numPredict: 500 })).trim();
    } catch {
    }
    const call = extractToolCall(reply);
    if (!call) {
      if (prose(reply)) store2.addAction(todoId, "think", prose(reply));
      history.push("Your reply had no JSON tool call. Reply with exactly one JSON object.");
      continue;
    }
    if (prose(reply)) store2.addAction(todoId, "think", prose(reply));
    switch (call.tool) {
      case "write_files": {
        for (const f of call.files ?? []) {
          if (!f.path) continue;
          const r = writeFile(dir, f.path, f.content ?? "");
          if (r.ok) {
            produced++;
            written.push(f.path);
          }
          store2.addAction(todoId, "write", r.output);
        }
        history.push(`write_files -> ${produced} file(s) written`);
        break;
      }
      case "write_file": {
        const r = writeFile(dir, call.path ?? "file.txt", call.content ?? "");
        if (r.ok) {
          produced++;
          written.push(call.path ?? "file.txt");
        }
        store2.addAction(todoId, "write", r.output);
        history.push(`write_file ${call.path} -> ${r.ok ? "ok" : r.output}`);
        break;
      }
      case "read_file": {
        const r = readFile(dir, call.path ?? "");
        store2.addAction(todoId, "read", `read ${call.path}`);
        history.push(`read_file ${call.path} ->
${r.output.slice(0, 800)}`);
        break;
      }
      case "list_dir": {
        const r = listDir(dir, call.path ?? ".");
        store2.addAction(todoId, "shell", `listed ${call.path ?? "."} (${r.output.split("\n").filter(Boolean).length} entries)`);
        history.push(`list_dir ->
${r.output.slice(0, 600)}`);
        break;
      }
      case "run": {
        const r = run(dir, call.cmd ?? "");
        store2.addAction(todoId, "shell", `$ ${call.cmd} \u2192 ${r.ok ? "ok" : "error"}`);
        history.push(`run \`${call.cmd}\` ->
${r.output.slice(0, 1e3)}`);
        break;
      }
      case "diagnostics": {
        const r = await diagnostics(dir, call.path ?? "");
        const head = r.output.split("\n")[0] ?? "";
        store2.addAction(todoId, "test", `diagnostics ${call.path} \u2192 ${head}`);
        history.push(`diagnostics ${call.path} ->
${r.output.slice(0, 1200)}`);
        break;
      }
      case "definition": {
        const r = await definition(dir, call.path ?? "", call.line, call.col);
        store2.addAction(todoId, "search", `definition ${call.path}:${call.line ?? 1}:${call.col ?? 1}`);
        history.push(`definition ${call.path}:${call.line ?? 1}:${call.col ?? 1} ->
${r.output.slice(0, 800)}`);
        break;
      }
      case "references": {
        const r = await references(dir, call.path ?? "", call.line, call.col);
        store2.addAction(todoId, "search", `references ${call.path}:${call.line ?? 1}:${call.col ?? 1}`);
        history.push(`references ${call.path}:${call.line ?? 1}:${call.col ?? 1} ->
${r.output.slice(0, 800)}`);
        break;
      }
      case "symbols": {
        const r = await symbols(dir, call.path ?? "");
        store2.addAction(todoId, "search", `symbols ${call.path}`);
        history.push(`symbols ${call.path} ->
${r.output.slice(0, 800)}`);
        break;
      }
      case "hover": {
        const r = await hover(dir, call.path ?? "", call.line, call.col);
        store2.addAction(todoId, "search", `hover ${call.path}:${call.line ?? 1}:${call.col ?? 1}`);
        history.push(`hover ${call.path}:${call.line ?? 1}:${call.col ?? 1} ->
${r.output.slice(0, 800)}`);
        break;
      }
      case "test": {
        const r = run(dir, call.cmd ?? "");
        testCmd = call.cmd ?? "";
        store2.addAction(todoId, "test", `tested: ${call.cmd} \u2192 ${r.ok ? "pass" : "fail"}`);
        if (r.ok) {
          finished = true;
          summary = call.summary ?? "tests passed";
        } else {
          history.push(`test FAILED: ${r.output.slice(0, 500)}`);
        }
        break;
      }
      case "finish": {
        finished = true;
        summary = call.summary ?? "done";
        if (call.test) testCmd = call.test;
        break;
      }
      default:
        history.push(`unknown tool: ${call.tool}`);
    }
  }
  let pass = false;
  let detail = "";
  if (testCmd) {
    const r = run(dir, testCmd);
    pass = r.ok;
    detail = r.ok ? "test passed" : `test failed: ${r.output.slice(0, 120)}`;
  } else {
    const n = fileCount(dir) || produced;
    pass = n > 0;
    detail = `${n} file(s) in workspace`;
  }
  if (written.length) {
    const d = await workspaceDiagnostics(dir, written);
    if (d.ran) {
      store2.addAction(todoId, "test", `lsp: ${d.errors} error(s), ${d.warnings} warning(s) across ${d.files} file(s)`);
      if (d.errors > 0) {
        pass = false;
        detail = `${d.errors} language-server error(s)`;
      }
    }
  }
  store2.addAction(todoId, "test", `tester \u2192 ${pass ? "pass" : "fail"} (${detail})`);
  store2.addMessage(todoId, "agent", `${summary || "Worked the task."} The tester ${pass ? "passed it" : "flagged it"} (${detail}).`);
  if (pass) store2.setTodoState(todoId, "done", "tester");
  store2.addEvent({ kind: pass ? "done" : "flag", title: `tester ${pass ? "passed" : "flagged"} \u201C${todo2.title}\u201D`, project_id: project.id, todo_id: todoId });
  const hash = gitCommit(dir, `${todo2.id}: ${todo2.title} (${pass ? "tester pass" : "flagged"})`);
  if (hash) {
    store2.setProjectGit(project.id, hash);
    store2.addAction(todoId, "write", `committed ${hash} to ${dir}`);
    store2.addEvent({ kind: "commit", title: `committed ${hash}`, detail: dir, project_id: project.id, todo_id: todoId });
  }
  store2.bumpContext(todoId, 420);
  return store2.thread(todoId);
}

// server/actions.ts
function pickProject(store2, id) {
  return (id ? store2.project(id) : void 0) ?? store2.projects()[0];
}
async function callAction(store2, call, automode) {
  switch (call.tool) {
    case "create_project": {
      const desc = (call.description ?? call.title ?? "").trim();
      if (!desc) return { label: "skipped an empty project", result: "no-op" };
      const title = await generateTitle(desc);
      const p = store2.createProject(title, desc, 48, 10, "dev-demo");
      return { label: `created a project \u201C${p.title}\u201D`, result: `project ${p.id}` };
    }
    case "create_request": {
      const title = (call.title ?? "").trim();
      if (!title) return { label: "skipped an empty request", result: "no-op" };
      const p = pickProject(store2, call.project_id);
      if (!p) return { label: "no project to file into", result: "no-op" };
      const t = store2.createRequest(p.id, title);
      return { label: `created a request \u201C${title}\u201D in \u201C${p.title}\u201D`, result: `request ${t.id}` };
    }
    case "plan": {
      const p = pickProject(store2, call.project_id);
      if (!p) return { label: "no project to plan into", result: "no-op" };
      const titles = (Array.isArray(call.titles) ? call.titles : []).map((t) => String(t).trim()).filter(Boolean).slice(0, 5);
      for (const t of titles) store2.createRequest(p.id, t);
      const g = call.goal ? ` for \u201C${call.goal}\u201D` : "";
      return { label: `planned ${titles.length} step${titles.length === 1 ? "" : "s"}${g} in \u201C${p.title}\u201D`, result: `${titles.length} requests` };
    }
    case "run_task": {
      const p = pickProject(store2, call.project_id);
      if (!p) return { label: "nothing to run", result: "no-op" };
      let todo2 = call.todo_id ? p.todos.find((t) => t.id === call.todo_id) : void 0;
      const want = (call.title ?? "").trim().toLowerCase();
      if (!todo2 && want) todo2 = p.todos.find((t) => t.title.toLowerCase() === want);
      if (!todo2 && (call.title ?? "").trim()) todo2 = store2.createRequest(p.id, call.title.trim());
      if (!todo2) todo2 = p.todos.find((t) => t.state !== "done");
      if (!todo2) return { label: "nothing to run", result: "no-op" };
      if (!automode) {
        return { label: `asked to start \u201C${todo2.title}\u201D \u2014 confirm to run it`, result: `not run (needs confirmation); request ${todo2.id}`, stop: true };
      }
      await runTodo(store2, todo2.id);
      return { label: `ran an agent on \u201C${todo2.title}\u201D \u2014 done`, result: `task ${todo2.id} finished` };
    }
    default:
      return { label: `unknown tool ${String(call.tool)}`, result: "error" };
  }
}
var TOOL_INSTRUCTION = `

You can also ACT, not only talk. Decide the action from the user's intent, then reply with ONE JSON object on its own line and nothing else:

- They want to RUN / START / FINISH / COMPLETE / DO / GET DONE / WORK ON / EXECUTE existing work \u2192 {"tool":"run_task"}   (add "title" only if they named a specific task)
- They want to ADD / CREATE / FILE a request or task \u2192 {"tool":"create_request","title":"..."}
- They want to PLAN / BREAK DOWN a goal into steps \u2192 {"tool":"plan","goal":"...","titles":["first step","second step"]}
- They want a brand-new project / "make an app for X" \u2192 {"tool":"create_project","description":"..."}

Rules:
- If they ask to run, start, finish or do existing work, you MUST call run_task. Never answer that with a plan or new requests.
- Use ONLY these tool names: create_project, create_request, plan, run_task. NEVER invent a tool.
- Do one action at a time. If the user asked for several things, keep going until they are all done, then stop.
- Use only project ids from the state above.
- For a plan, give 2-5 short, concrete titles.
- For anything else \u2014 a question, an opinion, small talk \u2014 just answer in one or two short sentences of plain prose, with no JSON.
- Never say you did something unless you emitted the block.`;
function runIntent(prompt) {
  const p = (prompt || "").toLowerCase();
  return /\b(run|start|kick ?off|finish|complete|execute|carry out|get (it|that|them) done|do (it|that|this|the rest|the remaining)|work on|go ahead)\b/.test(p) && !/\b(plan|break down|breakdown)\b/.test(p);
}
function* chunk(s) {
  for (const w of s.split(/(\s+)/)) if (w) yield w;
}
async function* toolStream(store2, input) {
  const history = input.messages?.length ? [...input.messages] : [{ role: "user", content: input.prompt ?? "" }];
  const system = input.system ? `${input.system}${TOOL_INSTRUCTION}` : TOOL_INSTRUCTION;
  const forceRun = runIntent(input.prompt ?? input.messages?.at(-1)?.content ?? "");
  let ranTask = false;
  for (let step = 0; step < 8; step++) {
    let reply = "";
    try {
      reply = await chat({ prompt: input.prompt ?? "", system, messages: history, numPredict: 500 });
    } catch (err) {
      yield { error: err.message };
      return;
    }
    let call = extractToolCall(reply);
    let forced = false;
    if (forceRun && !ranTask && (!call || call.tool !== "run_task")) {
      call = { tool: "run_task" };
      forced = true;
    }
    if (!call) {
      for (const piece of chunk(prose(reply) || reply)) yield { token: piece };
      return;
    }
    if (!forced) {
      const before = prose(reply);
      if (before) for (const piece of chunk(before)) yield { token: piece };
    }
    if (call.tool === "run_task" && input.automode) {
      yield { action: { name: "run_task", label: "starting an agent \u2014 this can take a minute" } };
    }
    history.push({ role: "assistant", content: reply });
    const out = await callAction(store2, call, !!input.automode);
    if (call.tool === "run_task") ranTask = true;
    yield { action: { name: call.tool, label: out.label } };
    if (out.stop) {
      for (const piece of chunk("Want me to start it? Turn on automode (or say go) and I will.")) yield { token: piece };
      return;
    }
    history.push({
      role: "user",
      content: `(${call.tool} -> ${out.result}) Keep going: take the next step if there is one, otherwise reply in one short sentence, with no JSON.`
    });
  }
  yield { token: " (stopped \u2014 too many steps)" };
}

// server/mcp.ts
var TOOLS = [
  {
    name: "list_projects",
    description: "List ptype projects with their brief, progress, health and git hash.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { title: "List projects", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  },
  {
    name: "create_project",
    description: "Create a project from a plain description. ptype generates the title and returns the project id.",
    inputSchema: {
      type: "object",
      properties: { description: { type: "string", description: "What the project is about." } },
      required: ["description"]
    },
    annotations: { title: "Create project", readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false }
  },
  {
    name: "list_requests",
    description: "List pending requests (unfinished tasks) across all projects.",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { title: "List requests", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  },
  {
    name: "create_request",
    description: "Create a new request (task) in a project. Returns the new task id.",
    inputSchema: {
      type: "object",
      properties: {
        title: { type: "string", description: "The concrete piece of work." },
        project_id: { type: "string", description: "Target project id (optional; defaults to the first project)." }
      },
      required: ["title"]
    },
    annotations: { title: "Create request", readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false }
  },
  {
    name: "run_task",
    description: "Run the ptype agent on a task; it writes real files into the project workspace and reports back.",
    inputSchema: { type: "object", properties: { todo_id: { type: "string" } }, required: ["todo_id"] },
    annotations: { title: "Run task", readOnlyHint: false, destructiveHint: true, idempotentHint: false, openWorldHint: true }
  },
  {
    name: "timeline",
    description: "Recent changes (seeds, agent runs, commits) newest last.",
    inputSchema: { type: "object", properties: { limit: { type: "number" } } },
    annotations: { title: "Timeline", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  },
  {
    name: "ask",
    description: "Ask the ptype model a question grounded in the current projects.",
    inputSchema: { type: "object", properties: { question: { type: "string" } }, required: ["question"] },
    annotations: { title: "Ask ptype", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: true }
  },
  {
    name: "diagnostics",
    description: "Run the language server on a file in a project workspace and return real compiler errors and warnings.",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "File path relative to the project workspace." },
        project_id: { type: "string", description: "Project id (optional; defaults to the first project)." }
      },
      required: ["path"]
    },
    annotations: { title: "Diagnostics", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  },
  {
    name: "get_provider",
    description: "The active model provider (kind, url, model).",
    inputSchema: { type: "object", properties: {}, additionalProperties: false },
    annotations: { title: "Get provider", readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false }
  }
];
function result(id, value) {
  return { jsonrpc: "2.0", id: id ?? null, result: value };
}
function error(id, code, message) {
  return { jsonrpc: "2.0", id: id ?? null, error: { code, message } };
}
function text(value) {
  return { content: [{ type: "text", text: value }] };
}
async function callTool(store2, name, args) {
  switch (name) {
    case "list_projects": {
      return store2.projects().map((p) => {
        const done = p.todos.filter((t) => t.state === "done").length;
        const overdue = p.todos.filter((t) => t.state === "overdue").length;
        const brief = p.description ? ` \u2014 ${p.description.replace(/\s+/g, " ").slice(0, 120)}` : "";
        return `${p.id}: ${p.title}${brief} (${done}/${p.todos.length} done, ${overdue} overdue${p.git ? `, git ${p.git}` : ""})`;
      }).join("\n") || "no projects";
    }
    case "create_project": {
      const description = String(args.description ?? "").trim();
      if (!description) return "description required";
      const title = await generateTitle(description);
      const p = store2.createProject(title, description);
      return `created ${p.id}: ${p.title}`;
    }
    case "list_requests": {
      const rows = store2.projects().flatMap((p) => p.todos.filter((t) => t.state !== "done").map((t) => `${t.id} [${t.state}] ${t.title} (${p.id})`));
      return rows.join("\n") || "nothing pending";
    }
    case "create_request": {
      const title = String(args.title ?? "").trim();
      if (!title) return "title required";
      const t = store2.createRequest(String(args.project_id ?? ""), title);
      return `created ${t.id}: ${t.title}`;
    }
    case "run_task": {
      const id = String(args.todo_id ?? "");
      const thread = await runTodo(store2, id);
      if (!thread) return `task ${id} not found`;
      const last = thread.messages[thread.messages.length - 1];
      return `${thread.title}: ${last?.text ?? "done"}`;
    }
    case "timeline": {
      const limit = Number(args.limit ?? 15);
      return store2.listEvents().slice(-limit).map((e) => `${new Date(e.ts).toISOString().slice(11, 19)} ${e.kind} ${e.title}`).join("\n") || "no events";
    }
    case "ask": {
      const q = String(args.question ?? "").trim();
      if (!q) return "question required";
      const state = store2.projects().map((p) => {
        const done = p.todos.filter((t) => t.state === "done").length;
        return `- ${p.title} (${p.id}): ${done}/${p.todos.length} done`;
      }).join("\n");
      return await chat({ prompt: `Projects:
${state}

Question: ${q}`, system: "You are ptype. Answer concisely in one or two sentences.", numPredict: 300 });
    }
    case "diagnostics": {
      const path = String(args.path ?? "").trim();
      if (!path) return "path required";
      const project = (args.project_id ? store2.project(String(args.project_id)) : void 0) ?? store2.projects()[0];
      if (!project) return "no project to inspect";
      const r = await diagnostics(projectDir(project.title), path);
      return r.output;
    }
    case "get_provider": {
      const p = getProvider();
      return `${p.kind} \xB7 ${p.model} \xB7 ${p.url}`;
    }
    default:
      throw new Error(`unknown tool: ${name}`);
  }
}
async function handleMcp(store2, body) {
  if (!body || body.jsonrpc !== "2.0") return error(body?.id, -32600, "invalid request");
  switch (body.method) {
    case "initialize":
      return result(body.id, {
        protocolVersion: body.params?.protocolVersion ?? "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "ptype", version: "1.0.0" }
      });
    case "notifications/initialized":
    case "notifications/cancelled":
      return null;
    case "ping":
      return result(body.id, {});
    case "tools/list":
      return result(body.id, { tools: TOOLS });
    case "tools/call": {
      try {
        const out = await callTool(store2, body.params?.name, body.params?.arguments ?? {});
        return result(body.id, text(out));
      } catch (err) {
        return result(body.id, { content: [{ type: "text", text: `error: ${err.message}` }], isError: true });
      }
    }
    default:
      return error(body.id, -32601, `method not found: ${body.method}`);
  }
}

// server/stt.ts
import { execFile } from "node:child_process";
import { writeFileSync as writeFileSync3, unlinkSync } from "node:fs";
import { homedir as homedir3, tmpdir } from "node:os";
import { join as join4 } from "node:path";
import { promisify } from "node:util";
var run2 = promisify(execFile);
var BIN = process.env.WHISPER_BIN ?? "whisper-cli";
var MODEL = process.env.WHISPER_MODEL ?? join4(homedir3(), "ptype/models/ggml-base.en.bin");
async function transcribe(wav) {
  const path = join4(tmpdir(), `ptype-${Date.now()}-${Math.random().toString(36).slice(2)}.wav`);
  writeFileSync3(path, wav);
  try {
    writeFileSync3(join4(tmpdir(), "ptype-last.wav"), wav);
  } catch {
  }
  try {
    const { stdout } = await run2(BIN, ["-ng", "-m", MODEL, "-f", path, "-nt", "-np"], {
      maxBuffer: 8 * 1024 * 1024,
      timeout: 12e4
    });
    const text2 = stdout.replace(/\[[^\]]*\]/g, "").replace(/\s+/g, " ").trim();
    console.log(`[stt] ${wav.length} bytes hdr=${wav.subarray(0, 44).toString("hex")} -> "${text2}"`);
    return text2;
  } finally {
    try {
      unlinkSync(path);
    } catch {
    }
  }
}

// server/http.ts
var CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET, POST, OPTIONS",
  "access-control-allow-headers": "content-type"
};
function createHandler(store2) {
  return async (req, res) => {
    if (req.method === "OPTIONS") {
      res.writeHead(204, CORS);
      res.end();
      return;
    }
    const send = (status, body) => {
      res.writeHead(status, { ...CORS, "content-type": "application/json" });
      res.end(JSON.stringify(body));
    };
    const url = new URL(req.url ?? "/", "http://localhost");
    const seg = url.pathname.split("/").filter(Boolean);
    if (seg[0] === "mcp" || seg[0] === "api" && seg[1] === "mcp") {
      if (req.method !== "POST") {
        return send(200, { name: "ptype", transport: "json-rpc-2.0 over http", tool: "POST /mcp" });
      }
      const body = await readJson(req);
      const resp = await handleMcp(store2, body);
      if (resp === null) {
        res.writeHead(202, CORS);
        res.end();
        return;
      }
      return send(200, resp);
    }
    try {
      if (seg[0] === "api" && seg[1] === "health" && req.method === "GET") {
        return send(200, { ok: true });
      }
      if (seg[0] === "api" && seg[1] === "config") {
        const host = req.headers.host ?? "localhost:8787";
        if (req.method === "GET") {
          return send(200, { ...getProvider(), workspace: rootDir(), mcp: `http://${host}/mcp`, contextLength: await contextLength() });
        }
        if (req.method === "POST") {
          const body = await readJson(req);
          const next = setProvider({ kind: body.kind, url: body.baseUrl, model: body.model, apiKey: body.apiKey });
          store2.addEvent({ kind: "provider", title: `provider \u2192 ${next.kind}:${next.model}`, detail: next.url });
          return send(200, { ...next, workspace: rootDir(), mcp: `http://${host}/mcp`, contextLength: await contextLength() });
        }
      }
      if (seg[0] === "api" && seg[1] === "models" && req.method === "GET") {
        return send(200, { models: await listModels(), recommended: recommendedModels(), provider: getProvider(), contextLength: await contextLength() });
      }
      if (seg[0] === "api" && seg[1] === "lsp") {
        if (req.method === "GET") return send(200, { servers: availableServers(), workspace: rootDir() });
        if (req.method === "POST") {
          const body = await readJson(req);
          if (!body?.path) return send(400, { error: "path required" });
          const project = body.project_id ? store2.project(body.project_id) : void 0;
          const dir = project ? projectDir(project.title) : rootDir();
          const op = body.op ?? "diagnostics";
          const result2 = op === "definition" ? await definition(dir, body.path, body.line, body.col) : op === "references" ? await references(dir, body.path, body.line, body.col) : op === "hover" ? await hover(dir, body.path, body.line, body.col) : op === "symbols" ? await symbols(dir, body.path) : await diagnostics(dir, body.path);
          return send(200, { op, path: body.path, ok: result2.ok, result: result2.output });
        }
      }
      if (seg[0] === "api" && seg[1] === "transcribe" && req.method === "POST") {
        const wav = await readRaw(req);
        if (!wav.length) return send(400, { error: "empty audio" });
        try {
          const text2 = await transcribe(wav);
          if (text2) store2.addEvent({ kind: "voice", title: `heard: ${text2.slice(0, 100)}` });
          return send(200, { text: text2 });
        } catch (err) {
          return send(500, { error: err.message });
        }
      }
      if (seg[0] === "api" && seg[1] === "dev" && seg[2] === "reset" && req.method === "POST") {
        store2.reset();
        store2.addEvent({ kind: "system", title: "ledger reset" });
        return send(200, { ok: true });
      }
      if (seg[0] === "api" && seg[1] === "dev" && seg[2] === "clear" && req.method === "POST") {
        store2.clearAll();
        return send(200, { ok: true });
      }
      if (seg[0] === "api" && seg[1] === "llm") {
        if (seg[2] === "health" && req.method === "GET") {
          const ok = await llmHealth();
          return send(ok ? 200 : 503, { ok });
        }
        if (seg[2] === "stream" && req.method === "POST") {
          const input = await readJson(req);
          if (!input?.prompt && !(input?.messages && input.messages.length)) return send(400, { error: "prompt or messages required" });
          res.writeHead(200, {
            ...CORS,
            "content-type": "text/event-stream",
            "cache-control": "no-cache",
            connection: "keep-alive"
          });
          const hb = setInterval(() => {
            try {
              res.write(": keep-alive\n\n");
            } catch {
            }
          }, 8e3);
          try {
            if (input.tools) {
              for await (const ev of toolStream(store2, input)) {
                res.write(`data: ${JSON.stringify(ev)}

`);
              }
            } else {
              for await (const token of chatStream(normalize3(input))) {
                res.write(`data: ${JSON.stringify({ token })}

`);
              }
            }
          } catch (err) {
            res.write(`data: ${JSON.stringify({ error: err.message })}

`);
          } finally {
            clearInterval(hb);
          }
          res.write("data: [DONE]\n\n");
          res.end();
          return;
        }
        if (req.method === "POST") {
          const input = await readJson(req);
          if (!input?.prompt && !(input?.messages && input.messages.length)) return send(400, { error: "prompt or messages required" });
          const t0 = Date.now();
          try {
            const text2 = await chat(normalize3(input));
            return send(200, { text: text2, model: input.model ?? process.env.LLM_MODEL ?? "gemma3:1b", ms: Date.now() - t0 });
          } catch (err) {
            return send(502, { error: err.message });
          }
        }
        return send(404, { error: "not found" });
      }
      if (seg[0] !== "api" || seg[1] !== "device" || !seg[2]) {
        return send(404, { error: "not found" });
      }
      const key = decodeURIComponent(seg[2]);
      if (req.method === "GET" && seg.length === 3) return send(200, store2.info(key));
      if (req.method === "GET" && seg[3] === "projects") return send(200, store2.projects());
      if (req.method === "GET" && seg[3] === "seeds") return send(200, store2.listSeeds(key));
      if (req.method === "GET" && seg[3] === "snapshot") return send(200, store2.snapshot());
      if (req.method === "POST" && seg[3] === "projects") {
        const body = await readJson(req);
        const description = (body?.description ?? "").trim();
        const rawTitle = (body?.title ?? "").trim();
        if (!description && !rawTitle) return send(400, { error: "description required" });
        const title = rawTitle || await generateTitle(description);
        const project = store2.createProject(title, description, body.dueHours, body.bufferHours, key);
        return send(201, { project });
      }
      if (req.method === "POST" && seg[3] === "run") {
        const body = await readJson(req);
        if (!body?.todoId) return send(400, { error: "todoId required" });
        const thread = await runTodo(store2, body.todoId);
        if (!thread) return send(404, { error: "task not found" });
        return send(200, { thread, snapshot: store2.snapshot() });
      }
      if (req.method === "POST" && seg[3] === "query") {
        const body = await readJson(req);
        const seed = store2.addSeed(key, body);
        return send(201, seed);
      }
      if (req.method === "POST" && seg[3] === "requests") {
        const body = await readJson(req);
        const list = body.requests ?? [{ project_id: body.project_id, title: body.title }];
        const created = list.filter((r) => r.title && r.title.trim()).map((r) => store2.createRequest(r.project_id ?? "", r.title.trim(), r.estimate));
        return send(201, { created });
      }
      if (req.method === "POST" && seg[3] === "mcp") {
        const body = await readJson(req);
        if (!body?.name) return send(400, { error: "name required" });
        store2.consultMCP(body.name);
        return send(200, { ok: true });
      }
      return send(404, { error: "not found" });
    } catch (err) {
      return send(400, { error: err.message });
    }
  };
}
function normalize3(input) {
  return {
    prompt: String(input.prompt ?? ""),
    model: input.model,
    numPredict: input.numPredict,
    name: input.name,
    context: input.context,
    system: input.system,
    messages: input.messages
  };
}
function readJson(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk2) => {
      data += chunk2;
      if (data.length > 1e6) req.destroy();
    });
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (err) {
        reject(err);
      }
    });
    req.on("error", reject);
  });
}
function readRaw(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk2) => {
      size += chunk2.length;
      if (size > 8e6) req.destroy();
      else chunks.push(chunk2);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

// server/store.ts
import { DatabaseSync } from "node:sqlite";

// server/data.ts
var HOUR = 3600 * 1e3;
var now = () => Date.now();
function todo(id, title, state) {
  return { id, title, state, tested_by: state === "done" ? "tester" : void 0 };
}
var SAMPLE_PROJECTS = [
  {
    id: "proj-album",
    title: "Musical inspiration for the album",
    due: now() + 34 * HOUR,
    target_finish: now() + 24 * HOUR,
    buffer_hours: 10,
    seed_ids: ["seed-1"],
    todos: [
      todo("t1", "Collect reference tracks", "done"),
      todo("t2", "Map the album arc", "done"),
      todo("t3", "Draft three motifs", "done"),
      todo("t4", "Score motif A", "done"),
      todo("t5", "Score motif B", "timely"),
      todo("t6", "Score motif C", "timely"),
      todo("t7", "Render stems", "timely"),
      todo("t8", "Master", "overdue")
    ]
  },
  {
    id: "proj-landing",
    title: "Launch landing page",
    due: now() + 52 * HOUR,
    target_finish: now() + 42 * HOUR,
    buffer_hours: 10,
    seed_ids: [],
    todos: [
      todo("l1", "Pick the headline", "done"),
      todo("l2", "Write the hero", "done"),
      todo("l3", "Build the sections", "timely"),
      todo("l4", "Wire the CTA", "timely"),
      todo("l5", "Ship it", "timely")
    ]
  }
];

// server/store.ts
var SCHEMA = `
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY, key TEXT NOT NULL, title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '', code TEXT NOT NULL DEFAULT '',
  due INTEGER NOT NULL, target_finish INTEGER NOT NULL, buffer_hours INTEGER NOT NULL,
  seed_ids TEXT NOT NULL DEFAULT '[]',
  git TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS todos (
  id TEXT PRIMARY KEY, project_id TEXT NOT NULL, ord INTEGER NOT NULL,
  title TEXT NOT NULL, detail TEXT, estimate INTEGER, slot INTEGER,
  state TEXT NOT NULL, tested_by TEXT
);
CREATE TABLE IF NOT EXISTS seeds (
  id TEXT PRIMARY KEY, key TEXT NOT NULL, kind TEXT NOT NULL, content TEXT NOT NULL,
  created_at INTEGER NOT NULL, project_id TEXT, intent TEXT, tags TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE IF NOT EXISTS threads (
  id TEXT PRIMARY KEY, todo_id TEXT NOT NULL, title TEXT NOT NULL,
  context_used INTEGER NOT NULL, context_limit INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY, thread_id TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS actions (
  id TEXT PRIMARY KEY, thread_id TEXT NOT NULL, todo_id TEXT NOT NULL,
  kind TEXT NOT NULL, label TEXT NOT NULL, ts INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts INTEGER NOT NULL, kind TEXT NOT NULL, title TEXT NOT NULL,
  detail TEXT, project_id TEXT, todo_id TEXT
);
`;
var Store = class {
  constructor(db) {
    this.db = db;
    this.db.exec(SCHEMA);
    this.migrate();
    this.seedIfEmpty();
  }
  db;
  /** Bring an older ledger up to date: projects gained description and code. */
  migrate() {
    const cols = this.db.prepare("PRAGMA table_info(projects)").all();
    const names = new Set(cols.map((c) => c.name));
    if (!names.has("description")) this.db.exec("ALTER TABLE projects ADD COLUMN description TEXT NOT NULL DEFAULT ''");
    if (!names.has("code")) this.db.exec("ALTER TABLE projects ADD COLUMN code TEXT NOT NULL DEFAULT ''");
  }
  seedIfEmpty() {
    const row = this.db.prepare("SELECT COUNT(*) AS n FROM projects").get();
    if (row.n > 0) return;
    this.seed();
  }
  seed() {
    this.clear();
    const now2 = Date.now();
    const insertProject = this.db.prepare(
      "INSERT INTO projects (id, key, title, description, code, due, target_finish, buffer_hours, seed_ids) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    const insertTodo = this.db.prepare(
      "INSERT INTO todos (id, project_id, ord, title, detail, estimate, slot, state, tested_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    const insertThread = this.db.prepare(
      "INSERT INTO threads (id, todo_id, title, context_used, context_limit) VALUES (?, ?, ?, ?, ?)"
    );
    const insertMessage = this.db.prepare("INSERT INTO messages (id, thread_id, role, text, ts) VALUES (?, ?, ?, ?, ?)");
    const insertAction = this.db.prepare(
      "INSERT INTO actions (id, thread_id, todo_id, kind, label, ts) VALUES (?, ?, ?, ?, ?, ?)"
    );
    for (const p of SAMPLE_PROJECTS) {
      insertProject.run(p.id, "dev-demo", p.title, p.description ?? "", p.code ?? "", p.due, p.target_finish, p.buffer_hours, JSON.stringify(p.seed_ids));
      this.addEvent({ kind: "project", title: `created \u201C${p.title}\u201D`, project_id: p.id });
      p.todos.forEach((todo2, i) => {
        insertTodo.run(todo2.id, p.id, i, todo2.title, todo2.detail ?? null, todo2.estimate ?? null, todo2.slot ?? null, todo2.state, todo2.tested_by ?? null);
        const threadId = `thread-${todo2.id}`;
        insertThread.run(
          threadId,
          todo2.id,
          todo2.title,
          Math.floor(todo2.estimate ? todo2.estimate * 900 : 2400),
          8e3
        );
        insertMessage.run(`${todo2.id}-m1`, threadId, "user", `Let's handle \u201C${todo2.title}\u201D.`, now2 - 54e5);
        insertMessage.run(`${todo2.id}-m2`, threadId, "agent", seedAgentLine(todo2.title, todo2.state), now2 - 51e5);
        if (todo2.state === "done") {
          insertAction.run(`${todo2.id}-a0`, threadId, todo2.id, "write", `wrote code for \u201C${todo2.title.toLowerCase()}\u201D`, now2 - 72e5);
          insertAction.run(`${todo2.id}-a1`, threadId, todo2.id, "test", `tested \u201C${todo2.title.toLowerCase()}\u201D`, now2 - 71e5);
        }
      });
    }
  }
  clear() {
    for (const t of ["actions", "messages", "threads", "seeds", "todos", "projects", "events"]) {
      this.db.exec(`DELETE FROM ${t}`);
    }
  }
  reset() {
    this.seed();
  }
  /** Remove every project, task, thread, seed and event. */
  clearAll() {
    this.clear();
    this.addEvent({ kind: "system", title: "cleared all projects and tasks" });
  }
  /**
   * Create a project. The title is generated from the user's description; the
   * id is a short 5-char alphanumeric code so it is easy to store and refer to.
   */
  createProject(title, description = "", dueHours = 48, bufferHours = 10, key = "dev-demo") {
    const seed = `${description}
${title}
${Date.now()}`;
    let code = shortCode(seed);
    let n = 2;
    while (this.db.prepare("SELECT 1 FROM projects WHERE id = ? OR code = ?").get(`proj-${code}`, code)) code = shortCode(`${seed}
${n++}`);
    const id = `proj-${code}`;
    const due = Date.now() + dueHours * 36e5;
    const buffer = bufferHours;
    const target = due - buffer * 36e5;
    this.db.prepare("INSERT INTO projects (id, key, title, description, code, due, target_finish, buffer_hours, seed_ids, git) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(id, key, title, description, code, due, target, buffer, "[]", "");
    this.addEvent({ kind: "project", title: `created \u201C${title}\u201D`, detail: description || void 0, project_id: id });
    return { id, title, description, code, due, target_finish: target, buffer_hours: buffer, seed_ids: [], todos: [] };
  }
  projects() {
    const rows = this.db.prepare("SELECT * FROM projects ORDER BY rowid").all();
    return rows.map((r) => ({
      id: r.id,
      title: r.title,
      description: r.description || void 0,
      code: r.code || void 0,
      due: r.due,
      target_finish: r.target_finish,
      buffer_hours: r.buffer_hours,
      seed_ids: JSON.parse(r.seed_ids),
      git: r.git || void 0,
      todos: this.db.prepare("SELECT * FROM todos WHERE project_id = ? ORDER BY ord").all(r.id).map(
        (t) => ({
          id: t.id,
          title: t.title,
          detail: t.detail ?? void 0,
          estimate: t.estimate ?? void 0,
          slot: t.slot ?? void 0,
          state: t.state,
          tested_by: t.tested_by ?? void 0
        })
      )
    }));
  }
  project(id) {
    return this.projects().find((p) => p.id === id);
  }
  todo(id) {
    for (const project of this.projects()) {
      const todo2 = project.todos.find((t) => t.id === id);
      if (todo2) return { todo: todo2, project };
    }
    return void 0;
  }
  actions(projectId) {
    const rows = this.db.prepare(
      "SELECT a.* FROM actions a JOIN todos t ON a.todo_id = t.id WHERE t.project_id = ? ORDER BY a.ts DESC, a.rowid DESC"
    ).all(projectId);
    return rows.map((r) => ({ id: r.id, kind: r.kind, label: r.label, ts: r.ts }));
  }
  thread(todoId) {
    const t = this.db.prepare("SELECT * FROM threads WHERE todo_id = ?").get(todoId);
    if (!t) return void 0;
    const messages2 = this.db.prepare("SELECT * FROM messages WHERE thread_id = ? ORDER BY ts, rowid").all(t.id);
    const actions = this.db.prepare("SELECT * FROM actions WHERE thread_id = ? ORDER BY ts DESC, rowid DESC").all(t.id);
    return {
      id: t.id,
      todo_id: t.todo_id,
      title: t.title,
      context_limit: t.context_limit,
      context_used: t.context_used,
      messages: messages2.map((m) => ({ id: m.id, role: m.role, text: m.text, ts: m.ts })),
      actions: actions.map((a) => ({ id: a.id, kind: a.kind, label: a.label, ts: a.ts }))
    };
  }
  listThreads() {
    const rows = this.db.prepare("SELECT todo_id FROM threads ORDER BY rowid").all();
    return rows.map((r) => this.thread(r.todo_id)).filter(Boolean);
  }
  snapshot() {
    const projects = this.projects();
    const threads = this.listThreads();
    const actions = {};
    for (const p of projects) actions[p.id] = this.actions(p.id);
    return { projects, threads, actions, events: this.listEvents() };
  }
  // ---- timeline (append-only log of every change) ----
  addEvent(e) {
    this.db.prepare("INSERT INTO events (ts, kind, title, detail, project_id, todo_id) VALUES (?, ?, ?, ?, ?, ?)").run(Date.now(), e.kind, e.title, e.detail ?? null, e.project_id ?? null, e.todo_id ?? null);
  }
  listEvents() {
    const rows = this.db.prepare("SELECT * FROM events ORDER BY ts, id").all();
    return rows;
  }
  addSeed(key, input) {
    const row = this.db.prepare("SELECT COUNT(*) AS n FROM seeds").get();
    const seed = {
      id: `seed-${row.n + 1}-${Date.now().toString(36)}`,
      kind: input.kind ?? "voice",
      content: (input.content ?? "").trim(),
      created_at: Date.now(),
      project_id: input.project_id,
      intent: input.intent,
      tags: input.tags ?? []
    };
    this.db.prepare("INSERT INTO seeds (id, key, kind, content, created_at, project_id, intent, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?)").run(seed.id, key, seed.kind, seed.content, seed.created_at, seed.project_id ?? null, seed.intent ?? null, JSON.stringify(seed.tags));
    if (seed.project_id) {
      const p = this.db.prepare("SELECT seed_ids FROM projects WHERE id = ?").get(seed.project_id);
      if (p) {
        const ids = JSON.parse(p.seed_ids);
        ids.push(seed.id);
        this.db.prepare("UPDATE projects SET seed_ids = ? WHERE id = ?").run(JSON.stringify(ids), seed.project_id);
      }
    }
    this.addEvent({ kind: "seed", title: seed.content, detail: seed.kind, project_id: seed.project_id });
    return seed;
  }
  listSeeds(key) {
    return this.db.prepare("SELECT * FROM seeds WHERE key = ? ORDER BY created_at").all(key);
  }
  info(key) {
    const projects = this.projects();
    return { key, projects: projects.length, seeds: this.listSeeds(key).length };
  }
  // ---- write helpers used by the agent runtime ----
  addAction(todoId, kind, label) {
    const row = this.db.prepare("SELECT COUNT(*) AS n FROM actions").get();
    const action = { id: `act-${row.n + 1}-${Date.now().toString(36)}`, kind, label, ts: Date.now() };
    this.db.prepare("INSERT INTO actions (id, thread_id, todo_id, kind, label, ts) VALUES (?, ?, ?, ?, ?, ?)").run(action.id, `thread-${todoId}`, todoId, kind, label, action.ts);
    return action;
  }
  addMessage(todoId, role, text2) {
    const row = this.db.prepare("SELECT COUNT(*) AS n FROM messages").get();
    const message = { id: `${todoId}-m-${row.n + 1}`, role, text: text2, ts: Date.now() };
    this.db.prepare("INSERT INTO messages (id, thread_id, role, text, ts) VALUES (?, ?, ?, ?, ?)").run(message.id, `thread-${todoId}`, role, text2, message.ts);
    return message;
  }
  setTodoState(todoId, state, testedBy) {
    this.db.prepare("UPDATE todos SET state = ?, tested_by = ? WHERE id = ?").run(state, testedBy ?? null, todoId);
  }
  bumpContext(todoId, add) {
    this.db.prepare("UPDATE threads SET context_used = MIN(context_limit, context_used + ?) WHERE todo_id = ?").run(add, todoId);
  }
  setProjectGit(projectId, hash) {
    this.db.prepare("UPDATE projects SET git = ? WHERE id = ?").run(hash, projectId);
  }
  /** Create a new request (task) in a project, with its own thread. */
  createRequest(projectId, title, estimate) {
    const project = this.project(projectId) ?? this.projects()[0];
    if (!project) throw new Error("no project to add a request to");
    const count = this.db.prepare("SELECT COUNT(*) AS n FROM todos").get().n;
    const ord = this.db.prepare("SELECT COUNT(*) AS n FROM todos WHERE project_id = ?").get(project.id).n;
    const id = `r${count + 1}`;
    this.db.prepare("INSERT INTO todos (id, project_id, ord, title, detail, estimate, slot, state, tested_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)").run(id, project.id, ord, title, null, estimate ?? null, null, "timely", null);
    this.db.prepare("INSERT INTO threads (id, todo_id, title, context_used, context_limit) VALUES (?, ?, ?, ?, ?)").run(`thread-${id}`, id, title, 0, 8e3);
    this.db.prepare("INSERT INTO messages (id, thread_id, role, text, ts) VALUES (?, ?, ?, ?, ?)").run(`${id}-m1`, `thread-${id}`, "user", `Let's handle \u201C${title}\u201D.`, Date.now());
    this.addEvent({ kind: "request", title: `created a request titled \u201C${title}\u201D`, project_id: project.id, todo_id: id });
    return { id, title, state: "timely", estimate: estimate ?? void 0 };
  }
  consultMCP(name) {
    this.addEvent({ kind: "mcp", title: `consulted an MCP for context (${name})`, detail: name });
  }
};
function seedAgentLine(title, state) {
  if (state === "done") return `Done and tested \u2014 \u201C${title}\u201D passed.`;
  if (state === "overdue") return `\u201C${title}\u201D slipped; want me to cut scope or push the deadline?`;
  return `Working through \u201C${title}\u201D now.`;
}
function shortCode(seed) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  const alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
  let out = "";
  let x = h >>> 0;
  for (let i = 0; i < 5; i++) {
    out += alphabet[x % 36];
    x = Math.floor(x / 36);
  }
  return out;
}
function openStore(path) {
  const db = new DatabaseSync(path);
  db.exec("PRAGMA journal_mode = WAL;");
  return new Store(db);
}

// server/index.ts
var port = Number(process.env.PORT ?? 8787);
var dbPath = process.env.PTYPE_DB ?? "ptype.db";
var store = openStore(dbPath);
createServer(createHandler(store)).listen(port, () => {
  console.log(`ptype api on http://localhost:${port} (db: ${dbPath})`);
});
